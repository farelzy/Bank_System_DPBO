/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Bank;

/**
 *
 * @author msi_k
 */
public interface IBankService {
    public void deposit(double amount);
    public void withdraw(double amount);
    public void getBalance();
}
